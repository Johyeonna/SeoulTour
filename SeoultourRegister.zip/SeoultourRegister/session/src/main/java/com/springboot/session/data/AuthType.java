package com.springboot.session.data;

public enum AuthType {
    ADMIN,USER,MANAGER
}
